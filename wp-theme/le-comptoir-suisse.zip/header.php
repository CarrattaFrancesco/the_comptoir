<?php
/**
 * Header Template
 * 
 * @package Le_Comptoir_Suisse
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Navigation -->
<nav class="navbar">
    <div class="logo">
        <?php
        if (has_custom_logo()) {
            the_custom_logo();
        } else {
            echo '<img src="' . esc_url(get_template_directory_uri() . '/assets/images/logo.svg') . '" alt="' . esc_attr(get_bloginfo('name')) . '">';
        }
        ?>
    </div>
    <div class="nav-left">
        <a href="#team" class="nav-link"><?php esc_html_e('Équipe', 'le-comptoir-suisse'); ?></a>
        <div class="nav-dropdown">
            <span class="nav-link" style="cursor: pointer;"><?php esc_html_e('Carte', 'le-comptoir-suisse'); ?></span>
            <div class="dropdown-menu">
                <?php
                $menus = get_option('comptoir_menus', array());
                $theatre_menu_id = isset($menus['theatre_menu']) ? $menus['theatre_menu'] : '';
                $after_theatre_menu_id = isset($menus['after_theatre_menu']) ? $menus['after_theatre_menu'] : '';
                $normal_menu_id = isset($menus['normal_menu']) ? $menus['normal_menu'] : '';
                
                $theatre_menu_url = $theatre_menu_id ? wp_get_attachment_url($theatre_menu_id) : '#';
                $after_theatre_menu_url = $after_theatre_menu_id ? wp_get_attachment_url($after_theatre_menu_id) : '#';
                $normal_menu_url = $normal_menu_id ? wp_get_attachment_url($normal_menu_id) : '#';
                ?>
                <?php if ($theatre_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($theatre_menu_url); ?>" target="_blank" class="dropdown-link"><?php esc_html_e('Theatre Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
                <?php if ($after_theatre_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($after_theatre_menu_url); ?>" target="_blank" class="dropdown-link"><?php esc_html_e('After Theatre Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
                <?php if ($normal_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($normal_menu_url); ?>" target="_blank" class="dropdown-link"><?php esc_html_e('Normal Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
            </div>
        </div>
        <a href="#opening-hours" class="nav-link"><?php esc_html_e('Horaires', 'le-comptoir-suisse'); ?></a>
        <a href="#booking" class="nav-link"><?php esc_html_e('Réservation', 'le-comptoir-suisse'); ?></a>
        <a href="#press" class="nav-link"><?php esc_html_e('Press', 'le-comptoir-suisse'); ?></a>
        <a href="#contact" class="nav-link"><?php esc_html_e('Contact', 'le-comptoir-suisse'); ?></a>
    </div>
    <div class="hamburger">
        <span></span>
        <span></span>
        <span></span>
    </div>
</nav>

<!-- Mobile Menu -->
<div class="mobile-menu">
    <div class="mobile-menu-items">
        <a href="#home" class="mobile-menu-link"><?php esc_html_e('Home', 'le-comptoir-suisse'); ?></a>
        <a href="#team" class="mobile-menu-link"><?php esc_html_e('Team', 'le-comptoir-suisse'); ?></a>
        <div class="mobile-submenu-toggle mobile-menu-link">
            <?php esc_html_e('Menus', 'le-comptoir-suisse'); ?>
            <div class="mobile-submenu">
                <?php if ($theatre_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($theatre_menu_url); ?>" target="_blank" class="mobile-submenu-link"><?php esc_html_e('Theatre Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
                <?php if ($after_theatre_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($after_theatre_menu_url); ?>" target="_blank" class="mobile-submenu-link"><?php esc_html_e('After Theatre Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
                <?php if ($normal_menu_url !== '#') : ?>
                    <a href="<?php echo esc_url($normal_menu_url); ?>" target="_blank" class="mobile-submenu-link"><?php esc_html_e('Normal Menu', 'le-comptoir-suisse'); ?></a>
                <?php endif; ?>
            </div>
        </div>
        <a href="#opening-hours" class="mobile-menu-link"><?php esc_html_e('Opening hours', 'le-comptoir-suisse'); ?></a>
        <a href="#booking" class="mobile-menu-link"><?php esc_html_e('Booking', 'le-comptoir-suisse'); ?></a>
        <a href="#press" class="mobile-menu-link"><?php esc_html_e('Press', 'le-comptoir-suisse'); ?></a>
        <a href="#contact" class="mobile-menu-link"><?php esc_html_e('Contact', 'le-comptoir-suisse'); ?></a>
    </div>
</div>
